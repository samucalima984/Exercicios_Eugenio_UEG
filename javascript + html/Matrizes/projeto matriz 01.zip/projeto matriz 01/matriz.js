class Matriz{
  #qLinhas;
  #qColunas;
  #matriz;

  constructor(qLinhas, qColunas){
    this.#qLinhas = qLinhas;
    this.#qColunas = qColunas;
    this.#matriz = new Array(this.#qLinhas);
    for (let linha = 0; linha < this.#qLinhas; linha++) {
      this.#matriz[linha] = new Array(this.#qColunas); 
    }
  }
  get linhas(){
    return this.#qLinhas;
  }
  get colunas(){
    return this.#qColunas;
  }

  gerarMatrizValoresAleatorios(){
    for (let linha = 0; linha < this.#qLinhas; linha++) {
      for (let coluna = 0; coluna < this.#qColunas; coluna++) {
        this.#matriz[linha][coluna] = Math.floor(Math.random() * 90 + 10);
      }
    }
  }
  adicionarValoresMatriz(){
    for (let linha = 0; linha < this.#qLinhas; linha++) {
        for (let coluna = 0; coluna < this.#qColunas; coluna++) {
            this.#matriz[linha][coluna] += this.#matriz[linha][coluna]; 
  }
}
}
  subtrairValoresMatriz(){
    for (let linha = 0; linha < this.#qLinhas; linha++) {
        for (let coluna = 0; coluna < this.#qColunas; coluna++) {
            this.#matriz[linha][coluna] -= this.#matriz[linha][coluna];
  }
}
}

  mostrarMatriz(){
    let str = "Matriz " + this.#qLinhas + "x" + this.#qColunas + "\n";
    for(let linha = 0; linha < this.#qLinhas; linha++){
      let saida = "";
      for(let coluna = 0; coluna < this.#qColunas; coluna++){
        saida += this.#matriz[linha][coluna] + "  ";
      }
      str += "\n" +saida;
    }
    return str;
  }
}

matrizA = new Matriz(4,3);
console.log("DADOS DA MATRIZ");
console.log("Quantidade de Linhas: " + matrizA.linhas);
console.log("Quantidade de Colunas: " + matrizA.colunas);
matrizA.gerarMatrizValoresAleatorios();
console.log(matrizA.mostrarMatriz());




